﻿using UnityEngine;

namespace CCE
{
    public class CCEInfo : MonoBehaviour
    {
        public string UUID = "";
    }
}
