﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
namespace CCE.AvatarPedestal
{
    public class CCEAvatarPedestal : MonoBehaviour
    {
        public string avatarBlurPrintId;
    }

}