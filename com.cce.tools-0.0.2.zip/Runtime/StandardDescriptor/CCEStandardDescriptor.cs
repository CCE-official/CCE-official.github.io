﻿using UnityEditor;
using UnityEngine;
using VRC.SDK3.Components;
using CCE.VideoDescriptor;
namespace CCE.StandardDescriptor
{
    public class CCEStandardDescriptor : MonoBehaviour
    {
        public bool usingSyncPickup;
        public VRCObjectSync[] syncPickups;


        public bool usingCustomMusic;

        public AudioClip customClip;




        public bool usingAnimator;

        public Animator targetAnimator;

        public string parameterName;


        public bool usingCustomVideo;

        public bool autoPlay;

        public CCEVideoDescriptor videoDescriptor;

    }
}
