﻿using UnityEditor;
using UnityEngine;
using UnityEngine.Video;
namespace CCE.VideoDescriptor
{
    public class CCEVideoDescriptor : MonoBehaviour
    {
        public bool isUrl = true;

        public VideoClip videoClip;

        public string videoUrl;

        public Transform videoControlPanelPos;

        public MeshRenderer screenRenderer;

        public Material defaultScreenMat;

    }
}
